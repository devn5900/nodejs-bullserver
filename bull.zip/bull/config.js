const redisConnection = {
  host: "127.0.0.1",
  port: 6379,
  password: "",
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
};

module.exports = redisConnection;
